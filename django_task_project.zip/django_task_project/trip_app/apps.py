from django.apps import AppConfig


class TripAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'trip_app'
