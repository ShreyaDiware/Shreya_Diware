from django.shortcuts import render

def add_trip(request):
    if request.method == 'POST':
        # Handle form submission and data validation
        # Example:
        user_id = request.POST.get('user_id')
        vehicle_id = request.POST.get('vehicle_id')
        route_id = request.POST.get('route_id')
        driver_name = request.POST.get('driver_name')
        trip_distance = request.POST.get('trip_distance')
        # Process the data as required
        
        return render(request, 'trip_service/add_trip.html')  # Render the same page after submission
    else:
        return render(request, 'trip_service/add_trip.html')

# trip_service/views.py
from django.shortcuts import render
from .models import Trip  # Import your Trip model

def list_trips(request):
    # Retrieve list of trips from the database
    trips = Trip.objects.all()  # Assuming Trip is your model
    
    # Pass the trips to the template for rendering
    return render(request, 'trip_service/list_trips.html', {'trips': trips})
# trip_service/views.py
from django.shortcuts import render
from .models import Trip  # Import your Trip model

def trip_details(request, trip_id):
    # Retrieve trip details from the database based on the trip_id
    trip = Trip.objects.get(pk=trip_id)  # Assuming Trip is your model
    
    # Pass the trip details to the template for rendering
    return render(request, 'trip_service/trip_details.html', {'trip': trip})

# trip_service/views.py
from django.shortcuts import render

def trip_page(request):
    # Add any necessary logic here
    return render(request, 'trip_service/add_trip.html')
