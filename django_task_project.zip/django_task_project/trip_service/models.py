from django.db import models

class Trip(models.Model):
    # Your trip model fields here
    pass
