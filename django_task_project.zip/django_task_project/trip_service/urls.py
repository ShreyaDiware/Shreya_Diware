from django.urls import path
from . import views

urlpatterns = [
    path('api/trip/add/', views.add_trip, name='add_trip'),
    path('api/trip/list/', views.list_trips, name='list_trips'),
    path('api/trip/<str:trip_id>/', views.trip_details, name='trip_details'),
    path('', views.trip_page, name='trip_page'),

]
# trip_service/urls.py
from django.urls import path
from . import views

urlpatterns = [
    path('list/', views.list_trips, name='list_trips'),
    # Add other URL patterns as needed
]
# trip_service/urls.py
from django.urls import path
from . import views

urlpatterns = [
    path('api/trip/<str:trip_id>/', views.trip_details, name='trip_details'),
    # Add other URL patterns as needed
]

# trip_service/urls.py
from django.urls import path
from . import views

urlpatterns = [
    path('', views.trip_page, name='trip_page'),
    # Add other URL patterns as needed
]
# trip_service/urls.py
from django.urls import path
from . import views

urlpatterns = [
    path('', views.trip_page, name='trip_page'),
    path('add/', views.add_trip, name='add_trip'),  # Add this line
    # Add other URL patterns as needed
]


