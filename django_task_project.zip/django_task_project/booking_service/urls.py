# In urls.py of booking_service app

from django.urls import path
from .views import booking_page
from booking_service.views import booking_page

urlpatterns = [
    path('booking/', booking_page, name='booking_page'),
    # other URL patterns
]

