# In views.py of booking_service app

from django.shortcuts import render, redirect
from .models import Trip
from .forms import BookingForm

def booking_page(request):
    if request.method == 'POST':
        form = BookingForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('success_url')  # Define your success URL
    else:
        form = BookingForm()
    return render(request, 'booking_service/booking_page.html', {'form': form})

from django.shortcuts import render

def booking_page(request):
    # Add your view logic here
    return render(request, 'booking/booking_page.html')  # Assuming you have a template named booking_page.html
