# In forms.py of booking_service app

from django import forms
from .models import Booking

class BookingForm(forms.ModelForm):
    class Meta:
        model = Booking
        fields = ['trip', 'customer_name', 'email', 'phone_number']
